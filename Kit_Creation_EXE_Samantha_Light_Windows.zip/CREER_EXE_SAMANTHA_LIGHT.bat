@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Construction Samantha Light EXE
echo.
echo ============================================
echo    SAMANTHA LIGHT - FABRICATION DU .EXE
echo ============================================
echo.
where py >nul 2>&1
if not errorlevel 1 (
  set "PY=py -3"
) else (
  where python >nul 2>&1
  if errorlevel 1 (
    echo ERREUR : Python n'est pas installe ou introuvable.
    echo Installer Python depuis https://www.python.org/downloads/windows/
    echo Cocher "Add python.exe to PATH" puis relancer ce fichier.
    pause
    exit /b 1
  )
  set "PY=python"
)
echo Verification de Python...
%PY% --version
if errorlevel 1 goto error
echo.
echo Installation de PyInstaller...
%PY% -m pip install --user --upgrade pyinstaller
if errorlevel 1 (
  echo Tentative sans --user...
  %PY% -m pip install --upgrade pyinstaller
  if errorlevel 1 goto error
)
echo.
echo Construction en cours... Cela peut prendre quelques minutes.
%PY% -m PyInstaller --noconfirm --clean --windowed --onedir --name Samantha_Light ^
 --add-data "demande_001.mp3;." ^
 --add-data "presentation_001.mp3;." ^
 --add-data "fin_001.mp3;." ^
 --add-data "sonar_sam_rotation.wav;." ^
 --add-data "sam_002_emission_radio.mp3;." ^
 "Samantha_002_Light_V1_3_Reconnaissance_Vocale.py"
if errorlevel 1 goto error
echo.
echo ============================================
echo SUCCES !
echo L'application est dans : dist\Samantha_Light
echo Pour la partager : clic droit sur le dossier
echo Samantha_Light, puis "Compresser dans un ZIP".
echo Ne pas envoyer seulement le fichier EXE.
echo ============================================
start "" "%~dp0dist\Samantha_Light"
pause
exit /b 0
:error
echo.
echo ERREUR : la compilation a echoue.
echo Faire une capture de cette fenetre et nous l'envoyer.
pause
exit /b 1
