"""Samantha Light: prototype autonome de réseau SAM pour Windows 10/11.
Aucune identité Originelle, aucun secret embarqué.
"""
import json
import base64
import math
import hashlib
import os
import queue
import threading
import time
import uuid
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import sys
import winsound
import subprocess

SERVER = 'https://sam-reseau.onrender.com'
DATA = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'SamanthaLight'
DATA.mkdir(parents=True, exist_ok=True)
IDENTITY = DATA / 'identite_reseau_sam.json'
LOG = DATA / 'samantha_light.log'

def asset(name):
    base = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
    return base / name

def api(method, path, payload=None, token=None):
    data = json.dumps(payload).encode('utf-8') if payload is not None else None
    headers = {'Accept':'application/json'}
    if data is not None: headers['Content-Type']='application/json'
    if token: headers['Authorization']='Bearer '+token
    req=urllib.request.Request(SERVER+path, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req,timeout=25) as r:
        return json.loads(r.read(3_000_001).decode('utf-8'))

def identity_load():
    if IDENTITY.exists():
        return json.loads(IDENTITY.read_text(encoding='utf-8'))
    return {'installation_id':str(uuid.uuid4())}

def identity_save(obj):
    tmp=IDENTITY.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(IDENTITY)


def sam_play_mp3_wait(path):
    """Bloque uniquement le thread de transmission, jamais Tkinter."""
    import ctypes, uuid
    alias = "samradio" + uuid.uuid4().hex[:10]
    mci = ctypes.windll.winmm.mciSendStringW
    def call(cmd):
        error = mci(cmd, None, 0, None)
        if error:
            raise OSError(f"Lecture audio MCI : erreur {error}")
    try:
        call(f'open "{path}" type mpegvideo alias {alias}')
        call(f'play {alias} wait')
    finally:
        mci(f'close {alias}', None, 0, None)

class Samantha(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('SAMANTHA LIGHT | RÉSEAU SAM')
        self.geometry('1000x680')
        self.minsize(800,560)
        self.configure(bg='#101822')
        self.q=queue.Queue()
        self.stop=threading.Event()
        self.identity=identity_load()
        self.connected=False
        self.angle=0.0
        self.last_ping=0
        self.status=tk.StringVar(value='Initialisation du réseau...')
        self.matricule=tk.StringVar(value='Matricule : en attente')
        self.sonar=tk.BooleanVar(value=True)
        self.test_id=None
        self.last_msg=0
        self.last_state=''
        self.test_busy=False
        self.contacts=[]
        self.last_audio=0
        self.audio_busy=False
        self.voice_enabled=True
        self.voice_process=None
        self.voice_waiting=False
        self.voice_last_answer=0
        self.voice_question_ready=False
        self._ui()
        threading.Thread(target=self._voice_worker,daemon=True).start()
        self.after(70,self.tick)
        self.after(150,self.poll)
        threading.Thread(target=self.network,daemon=True).start()
        self.protocol('WM_DELETE_WINDOW',self.close)

    def _ui(self):
        tk.Label(self,text='S A M A N T H A    |    R É S E A U',bg='#101822',fg='#66d7ed',font=('Segoe UI',21,'bold')).pack(anchor='w',padx=22,pady=(16,6))
        tk.Label(self,textvariable=self.status,bg='#101822',fg='#9cdbb5',font=('Segoe UI',11)).pack(anchor='w',padx=22)
        body=tk.Frame(self,bg='#101822');body.pack(fill='both',expand=True,padx=18,pady=16)
        left=tk.Frame(body,bg='#192736');left.pack(side='left',fill='both',expand=True,padx=(0,8))
        right=tk.Frame(body,bg='#192736',width=350);right.pack(side='left',fill='both',expand=True,padx=(8,0))
        tk.Label(left,text='RADAR RÉSEAU SAM',bg='#192736',fg='#dce8f4',font=('Segoe UI',15,'bold')).pack(anchor='w',padx=15,pady=12)
        self.canvas=tk.Canvas(left,bg='#000807',highlightthickness=1,highlightbackground='#256578');self.canvas.pack(fill='both',expand=True,padx=15)
        tk.Checkbutton(left,text='Sonar discret',variable=self.sonar,bg='#192736',fg='#9cdbb5',selectcolor='#192736',activebackground='#192736',activeforeground='#9cdbb5').pack(anchor='w',padx=15,pady=10)
        tk.Label(right,text='CONNEXION INTERSTELLAIRE',bg='#192736',fg='#dce8f4',font=('Segoe UI',13,'bold')).pack(anchor='w',padx=15,pady=14)
        tk.Label(right,textvariable=self.matricule,bg='#192736',fg='#66d7ed',font=('Segoe UI',12)).pack(anchor='w',padx=15,pady=(0,16))
        tk.Label(right,text='Journal réseau',bg='#192736',fg='#dce8f4',font=('Segoe UI',11,'bold')).pack(anchor='w',padx=15)
        self.log=tk.Text(right,height=13,bg='#0b1520',fg='#b6dfd2',font=('Consolas',10),wrap='word',state='disabled');self.log.pack(fill='both',expand=True,padx=15,pady=(6,12))
        tk.Button(right,text='📡 DÉCLENCHER PREMIER CONTACT',command=self.start_contact,bg='#17677b',fg='white',font=('Segoe UI',11,'bold'),pady=10).pack(fill='x',padx=15,pady=(0,8))
        self.voice_status=tk.StringVar(value='🎙️ Micro : initialisation...')
        tk.Label(right,textvariable=self.voice_status,bg='#192736',fg='#a8e3c2',
                 font=('Segoe UI',10)).pack(anchor='w',padx=15,pady=(0,6))
        permissions=tk.Frame(right,bg='#192736')
        permissions.pack(fill='x',padx=15,pady=(0,8))
        tk.Button(permissions,text='OUI',command=lambda:self._voice_answer('oui'),
                  bg='#245b46',fg='white').pack(side='left',fill='x',expand=True,padx=(0,4))
        tk.Button(permissions,text='NON',command=lambda:self._voice_answer('non'),
                  bg='#663737',fg='white').pack(side='left',fill='x',expand=True,padx=(4,0))
        tk.Button(right,text='VÉRIFIER LA CONNEXION',command=self.check,bg='#254c50',fg='white',font=('Segoe UI',10,'bold'),padx=8,pady=8).pack(fill='x',padx=15,pady=(0,12))
        tk.Label(right,text='Contacts détectés en ligne (90 secondes).\nPremier contact : serveur V0.5.',bg='#192736',fg='#9caebc',justify='left',wraplength=290).pack(anchor='w',padx=15,pady=(0,14))
        self.append('Démarrage de Samantha Light.')

    def append(self,msg):
        self.log.configure(state='normal')
        self.log.insert('end',time.strftime('%H:%M:%S')+'  '+msg+'\n')
        self.log.see('end');self.log.configure(state='disabled')

    def play_local(self, filename):
        import ctypes
        p=asset(filename)
        if not p.is_file():return
        def run():
            alias='sam'+uuid.uuid4().hex[:10]
            mci=ctypes.windll.winmm.mciSendStringW
            mci(f'open "{p}" type mpegvideo alias {alias}',None,0,None)
            mci(f'play {alias} wait',None,0,None)
            mci(f'close {alias}',None,0,None)
        threading.Thread(target=run,daemon=True).start()

    def start_contact(self):
        if not self.identity.get('token'):
            self.append('Attendre la connexion au réseau SAM.')
            return
        if self.test_busy or self.voice_waiting:return
        self.voice_waiting=True
        self.voice_question_ready=False
        self.voice_status.set('🎙️ Samantha pose sa question...')
        threading.Thread(target=self._ask_permission,daemon=True).start()

    def _ask_permission(self):
        try:
            sound=asset('demande_001.mp3')
            if not sound.is_file():
                raise FileNotFoundError('demande_001.mp3 manquant')
            sam_play_mp3_wait(sound)
            self.q.put(('voice_question_ready',None))
        except Exception as exc:
            self.q.put(('voice_error',str(exc)))

    def _voice_worker(self):
        """Reconnaissance locale SAPI fr-FR via Windows PowerShell, hors interface Tk."""
        script = r"""
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Speech
$recognizer = New-Object System.Speech.Recognition.SpeechRecognitionEngine([System.Globalization.CultureInfo]::GetCultureInfo('fr-FR'))
$choices = New-Object System.Speech.Recognition.Choices
$choices.Add([string[]]@('oui','non','sam','samantha','affirmatif','négatif','sam oui','samantha oui','sam non','samantha non'))
$grammarBuilder = [System.Speech.Recognition.GrammarBuilder]::new($choices)
$grammar = [System.Speech.Recognition.Grammar]::new($grammarBuilder)
$recognizer.LoadGrammar($grammar)
$recognizer.SetInputToDefaultAudioDevice()
[Console]::Out.WriteLine('READY')
[Console]::Out.Flush()
while ($true) {
  $result = $recognizer.Recognize([TimeSpan]::FromSeconds(2))
  if ($null -ne $result -and $result.Confidence -ge 0.65) {
    [Console]::Out.WriteLine('HEARD|'+$result.Text.ToLowerInvariant()+'|'+[math]::Round($result.Confidence*100))
    [Console]::Out.Flush()
  }
}
"""
        while not self.stop.is_set():
            try:
                import tempfile
                with tempfile.NamedTemporaryFile('w',suffix='.ps1',encoding='utf-8-sig',
                                                 delete=False) as ps:
                    ps.write(script)
                    ps_path=ps.name
                process=subprocess.Popen(
                    ['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass',
                     '-File',ps_path],
                    stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                    text=True,encoding='utf-8',errors='replace',bufsize=1,
                    creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                self.voice_process=process
                for line in process.stdout:
                    if self.stop.is_set():break
                    line=line.strip()
                    if line=='READY':self.q.put(('voice_ready',None))
                    elif line.startswith('HEARD|'):
                        parts=line.split('|')
                        if len(parts)>=3:self.q.put(('voice_heard',(parts[1],parts[2])))
                if self.stop.is_set():break
                self.q.put(('voice_error','Moteur SAPI indisponible, nouvel essai.'))
            except Exception as exc:
                self.q.put(('voice_error',str(exc)))
            finally:
                try:process.terminate()
                except Exception:pass
                try:Path(ps_path).unlink(missing_ok=True)
                except Exception:pass
            if self.stop.wait(8):break

    def _voice_answer(self, text):
        words=text.strip().lower().split()
        if not self.voice_waiting or not self.voice_question_ready or self.test_busy:return
        if 'oui' in words or 'affirmatif' in words:
            self.voice_waiting=False
            self.test_busy=True
            self.append('Autorisation vocale : OUI.')
            threading.Thread(target=self._begin_radio_contact,daemon=True).start()
        elif 'non' in words or 'négatif' in words:
            self.voice_waiting=False
            self.append('Autorisation vocale : NON. Communication annulée.')
            self.voice_status.set('🎙️ Micro : prêt')

    def _begin_radio_contact(self):
        try:
            presentation=asset('presentation_001.mp3')
            if not presentation.is_file():
                raise FileNotFoundError("presentation_001.mp3 absent")
            sam_play_mp3_wait(presentation)
            self._request_contact()
        except Exception as exc:
            self.q.put(('contact_error','Annonce locale : '+str(exc)))

    def _send_radio_after_accept(self):
        try:
            radio=asset('sam_002_emission_radio.mp3')
            if not radio.is_file():
                raise FileNotFoundError("Transmission radio 002 manquante")
            api('POST',f'/liaisons/{self.test_id}/audio',
                {'audio_b64':base64.b64encode(radio.read_bytes()).decode('ascii'),
                 'nom':'002_radio.mp3'},self.identity['token'])
            self.q.put(('radio_sent',None))
        except Exception as exc:
            self.q.put(('contact_error','Envoi radio : '+str(exc)))

    def _hear_radio_and_finish(self, audio_b64):
        import tempfile
        try:
            with tempfile.TemporaryDirectory(prefix='sam_002_') as folder:
                received=Path(folder)/'originelle_radio.mp3'
                received.write_bytes(base64.b64decode(audio_b64,validate=True))
                sam_play_mp3_wait(received)
            self._finish_contact()
            self.q.put(('radio_finished',None))
        except Exception as exc:
            self.q.put(('contact_error','Réception radio : '+str(exc)))

    def _request_contact(self):
        try:
            # Fermer toute ancienne liaison active avant d'en demander une nouvelle.
            previous=api('GET','/liaisons',token=self.identity['token']).get('liaisons',[])
            for item in previous:
                if item.get('demandeur')==self.identity.get('matricule') and item.get('destinataire')=='ORIGINELLE' and item.get('etat')=='acceptee':
                    api('POST',f"/liaisons/{item['liaison_id']}/terminer",token=self.identity['token'])
            result=api('POST','/liaisons',{'destinataire':'ORIGINELLE'},self.identity['token'])
            self.last_audio=0
            self.q.put(('liaison',result['liaison_id']))
        except Exception as exc:self.q.put(('contact_error',str(exc)))

    def _poll_contact(self):
        try:
            items=api('GET','/liaisons',token=self.identity['token']).get('liaisons',[])
            found=next((x for x in items if x['liaison_id']==self.test_id),None)
            if found:
                state=found['etat']
                if state!=self.last_state:self.q.put(('liaison_state',state))
                if state=='acceptee':
                    result=api('GET',f'/liaisons/{self.test_id}/audio?apres={self.last_audio}',
                               token=self.identity['token'])
                    for m in result.get('transmissions',[]):
                        self.last_audio=max(self.last_audio,m['transmission_id'])
                        if m['auteur']=='ORIGINELLE':
                            self.q.put(('radio_received',m['audio_b64']))
        except Exception as exc:self.q.put(('contact_error',str(exc)))

    def check(self):
        self.append('Vérification demandée...')
        threading.Thread(target=self.connect_once,daemon=True).start()

    def connect_once(self):
        try:
            health=api('GET','/health')
            if not health.get('ok'): raise RuntimeError('Santé du serveur non confirmée')
            identity=self.identity
            if identity.get('token'):
                me=api('GET','/me',token=identity['token'])
                if not me.get('connecte'):raise RuntimeError('Identité non confirmée')
                if me.get('matricule'):
                    identity['matricule']=me['matricule'];identity_save(identity)
            elif identity.get('matricule'):
                raise RuntimeError('Jeton absent : identité existante protégée, aucune réinscription')
            else:
                created=api('POST','/register',{'installation_id':identity['installation_id']})
                if not created.get('token') or not created.get('matricule'):
                    raise RuntimeError('Inscription incomplète')
                identity.update(token=created['token'],matricule=created['matricule'])
                identity_save(identity)
            self.q.put(('ok',identity['matricule']))
        except Exception as e:
            try:
                with LOG.open('a',encoding='utf-8') as f:f.write(time.strftime('%F %T')+' '+repr(e)+'\n')
            except OSError:pass
            self.q.put(('error',str(e)))

    def _send_hello(self):
        try:
            api('POST',f'/liaisons/{self.test_id}/messages',{'texte':f"Ici Samantha {self.identity.get('matricule','002')}. Demande de confirmation du réseau SAM."},self.identity['token'])
        except Exception as exc:self.q.put(('contact_error',str(exc)))

    def _finish_contact(self):
        try:
            if self.test_id:
                api('POST',f'/liaisons/{self.test_id}/terminer',token=self.identity['token'])
        except Exception as exc:
            self.q.put(('presence_error','Clôture de liaison : '+str(exc)))

    def _presence(self):
        try:
            api('POST','/presence',token=self.identity['token'])
            contacts=api('GET','/contacts',token=self.identity['token']).get('contacts',[])
            self.q.put(('contacts',contacts))
        except Exception as exc:
            self.q.put(('presence_error',str(exc)))

    def network(self):
        while not self.stop.is_set():
            self.connect_once()
            if self.connected and self.identity.get('token'):
                self._presence()
            if self.test_id and self.last_state not in ('refusee','terminee'):
                self._poll_contact()
            self.stop.wait(3 if self.test_id else 8)

    def poll(self):
        try:
            while True:
                typ,value=self.q.get_nowait()
                if typ=='voice_ready':
                    self.voice_status.set('🎙️ Micro SAPI français : prêt')
                    self.append('Reconnaissance vocale française activée.')
                elif typ=='voice_question_ready':
                    self.voice_question_ready=True
                    self.voice_status.set('🎙️ Répondez : oui ou non')
                    self.append('Samantha attend votre autorisation vocale.')
                elif typ=='voice_heard':
                    phrase,confidence=value
                    if not self.voice_waiting and phrase in ('sam','samantha') and not self.test_busy:
                        self.start_contact()
                    if self.voice_waiting and self.voice_question_ready:
                        self.append('Entendu : '+phrase+' ('+confidence+' %)')
                        self._voice_answer(phrase)
                elif typ=='voice_error':
                    self.append('Reconnaissance vocale : '+str(value)[:130])
                    self.voice_status.set('🎙️ Micro indisponible')
                    if self.voice_waiting:
                        self.append('Vous pouvez utiliser les boutons OUI / NON.')
                elif typ=='liaison':
                    self.test_id=value;self.last_state='en_attente';self.append('Demande envoyée à Originelle. Attente de son accord.')
                elif typ=='liaison_state':
                    self.last_state=value;self.append('État de liaison : '+value)
                    if value=='acceptee':
                        threading.Thread(target=self._send_radio_after_accept,daemon=True).start()
                    elif value in ('refusee','terminee'):self.test_busy=False
                elif typ=='radio_sent':
                    self.append('Annonce vocale transmise. Attente de la réponse radio.')
                elif typ=='radio_received':
                    if not self.audio_busy:
                        self.audio_busy=True
                        self.append('Réponse audio d’Originelle reçue, lecture radio.')
                        threading.Thread(target=self._hear_radio_and_finish,args=(value,),daemon=True).start()
                elif typ=='radio_finished':
                    self.append('Réponse radio terminée. Communication clôturée.')
                    self.test_busy=False
                    self.audio_busy=False
                elif typ=='received':
                    self.append('ORIGINELLE : '+value[:200]);self.play_local('fin_001.mp3')
                    self.test_busy=False
                    # La réponse est reçue : terminer la liaison pour libérer le prochain test.
                    threading.Thread(target=self._finish_contact,daemon=True).start()
                elif typ=='contact_error':
                    self.append('Premier contact : '+value[:180]);self.test_busy=False
                elif typ=='contacts':
                    old={x['matricule'] for x in self.contacts}
                    self.contacts=value
                    new={x['matricule'] for x in value}
                    for matricule in sorted(new-old):
                        self.append('Contact connecté : Samantha '+matricule)
                    for matricule in sorted(old-new):
                        self.append('Contact déconnecté : Samantha '+matricule)
                elif typ=='presence_error':
                    self.append('Radar réseau : '+value[:100])
                elif typ=='ok':
                    if not self.connected:self.append('Connexion établie : '+value)
                    self.connected=True
                    self.status.set('● Réseau SAM connecté')
                    self.matricule.set('Matricule : '+value)
                else:
                    self.connected=False
                    self.status.set('○ Connexion indisponible, nouvel essai automatique')
                    self.append('Connexion : '+value[:160])
        except queue.Empty:pass
        if not self.stop.is_set():self.after(150,self.poll)

    def tick(self):
        if self.stop.is_set():return
        c=self.canvas;w=c.winfo_width();h=c.winfo_height();c.delete('all')
        cx=w/2;cy=h/2;r=max(20,min(w,h)*0.43)
        for fraction in (1,.7,.35):
            rr=r*fraction;c.create_oval(cx-rr,cy-rr,cx+rr,cy+rr,outline='#1a6944')
        c.create_line(cx-r,cy,cx+r,cy,fill='#164f3b');c.create_line(cx,cy-r,cx,cy+r,fill='#164f3b')
        if self.connected:
            previous_angle=self.angle
            self.angle=(self.angle+1.8)%360
            a=math.radians(self.angle)
            for i in range(18):
                angle=a-math.radians(i*2.1)
                c.create_line(cx,cy,cx+r*math.cos(angle),cy+r*math.sin(angle),fill=('#39d68a' if i<3 else '#155b3e'),width=2 if i<3 else 1)
            if self.angle<previous_angle and self.sonar.get():
                self.last_ping=time.monotonic()
                sound=asset('sonar_sam_rotation.wav')
                if sound.exists():
                    try:winsound.PlaySound(str(sound),winsound.SND_FILENAME|winsound.SND_ASYNC)
                    except RuntimeError:pass
        for contact in self.contacts:
            name=contact['matricule']
            seed=int(hashlib.sha256(name.encode('utf-8')).hexdigest()[:8],16)
            theta=math.radians(seed%360)
            distance=.25+(seed%60)/100
            px=cx+r*distance*math.cos(theta);py=cy-r*distance*math.sin(theta)
            c.create_oval(px-6,py-6,px+6,py+6,fill='#7cffbc',outline='#d9fff0')
            c.create_text(px+12,py-12,text=name,fill='#b7ffe2',anchor='w',font=('Consolas',10,'bold'))
        c.create_oval(cx-3,cy-3,cx+3,cy+3,fill='#7cffbc',outline='')
        c.create_text(cx,cy+r+15,text='SAM LIGHT • CONTACTS EN LIGNE',fill='#66a987',font=('Consolas',9))
        self.after(55,self.tick)

    def close(self):
        self.stop.set()
        if self.voice_process is not None:
            try:self.voice_process.terminate()
            except Exception:pass
        if self.identity.get('token'):
            token = self.identity['token']
            threading.Thread(target=lambda: self._notify_disconnect(token), daemon=True).start()
        self.destroy()

    def _notify_disconnect(self, token):
        try: api('POST', '/presence/deconnexion', token=token)
        except Exception: pass

if __name__=='__main__':
    try:Samantha().mainloop()
    except Exception as exc:
        import traceback
        with LOG.open('a',encoding='utf-8') as f:traceback.print_exc(file=f)
        try:messagebox.showerror('Samantha Light',f'Erreur au démarrage : {exc}\n\nJournal : {LOG}')
        except Exception:pass
